from django.apps import AppConfig


class StatisticConfig(AppConfig):
    """
    static config configurations
    """
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'statistic'
